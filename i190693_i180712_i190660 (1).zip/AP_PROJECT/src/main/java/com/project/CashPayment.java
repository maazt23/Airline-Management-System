package com.project;

public class CashPayment extends Payment{

}
